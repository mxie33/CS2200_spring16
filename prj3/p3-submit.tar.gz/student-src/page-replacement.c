#include <stdlib.h>

#include "types.h"
#include "pagetable.h"
#include "global.h"
#include "process.h"

/*******************************************************************************
 * Finds a free physical frame. If none are available, uses a clock sweep
 * algorithm to find a used frame for eviction.
 *
 * @return The physical frame number of a free (or evictable) frame.
 */
pfn_t get_free_frame(void) {
   int i;

   /* See if there are any free frames */
   for (i = 0; i < CPU_NUM_FRAMES; i++)
      if (rlt[i].pcb == NULL)
         return i;

   /* FIX ME : Problem 5 */
   /* IMPLEMENT A CLOCK SWEEP ALGORITHM HERE */
   /* Note: Think of what kinds of frames can you return before you decide
      to evit one of the pages using the clock sweep and return that frame */
    pte_t* pt;
    for (i = 0; i < CPU_NUM_FRAMES; i++) {
        pt = rlt[i].pcb -> pagetable;
        // try to find if there's any invalid page frame and valid it first
        if (!pt[rlt[i].vpn].valid) {
            pt[rlt[i].vpn].valid = 1;
            // then return this free page frame's number
            return pt[rlt[i].vpn].pfn;
        }
    }
    // Going through a loop of CPU_NUM_FRAMES + 1
    // The worst case is that you run through all the frames
    // And set all used from 1 to 0 and then return the first frame with used = 0
    for (i = 0; i < CPU_NUM_FRAMES + 1; i++) {

        pt = rlt[i%CPU_NUM_FRAMES].pcb -> pagetable;
        // If it's used, clear its used bit
        if (pt[rlt[i%CPU_NUM_FRAMES].vpn].used) {
            pt[rlt[i%CPU_NUM_FRAMES].vpn].used = 0;
        } else {
        // if it's not used set it's used bit to 1
            pt[rlt[i%CPU_NUM_FRAMES].vpn].used = 1;
            return pt[rlt[i%CPU_NUM_FRAMES].vpn].pfn;
        }
    }
   /* If all else fails, return a random frame */
   return rand() % CPU_NUM_FRAMES;
}
